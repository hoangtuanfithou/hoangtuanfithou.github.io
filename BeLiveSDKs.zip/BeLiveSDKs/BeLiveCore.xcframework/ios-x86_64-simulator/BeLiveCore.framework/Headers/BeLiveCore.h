///
/// Project: BeLiveSDK
/// File: BeLiveCore.h
/// Created by thule on 02/11/2022.
/// Copyright © 2016-2022 BeLive Technology. All rights reserved.
///

#import <Foundation/Foundation.h>

//! Project version number for BeLiveCore.
FOUNDATION_EXPORT double BeLiveCoreVersionNumber;

//! Project version string for BeLiveCore.
FOUNDATION_EXPORT const unsigned char BeLiveCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BeLiveCore/PublicHeader.h>


