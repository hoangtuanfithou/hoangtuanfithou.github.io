///
/// Project: BeLive
/// File: BeLiveAudiencePolling.h
/// Created by thule on 08/11/2022.
/// Copyright © 2016-2022 BeLive Technology. All rights reserved.
///

#import <Foundation/Foundation.h>

//! Project version number for BeLiveAudiencePolling.
FOUNDATION_EXPORT double BeLiveAudiencePollingVersionNumber;

//! Project version string for BeLiveAudiencePolling.
FOUNDATION_EXPORT const unsigned char BeLiveAudiencePollingVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BeLiveAudiencePolling/PublicHeader.h>


